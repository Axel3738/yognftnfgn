# Video Ad Briefs – Seatcover Batch #6 (2026-08-12)

Two videos, both built on one measured result. Read this before starting.

## Why this batch exists
`Seatcover_PD_13_H1` — the towel-callout hook from batch #4 — is **the first briefed ad in this account to reach significance**: 6 purchases, CPA 329 kr, profitable (break-even is 474 kr). It measured two things clearly:

- **The hook works as attention:** CTR **3.87 %** (highest of any PD ad; the winner does 2.69 %) and hold 13.6 % (winner: 11.7 %).
- **The audience it brings converts worse:** LPV→purchase **1.81 %** vs the winner's 2.67 %.

So: recognition stops people, but pulls a broader, less purchase-ready crowd. These two briefs test the two obvious responses — **qualify them earlier** (`PD_18_H1`, price moved into the video) and **check the hook type replicates** (`PD_19_H1`, same formula on a different habit).

## Product facts (never improvise)
- 600D Oxford, water-repellent, padded inside, adjustable straps, on in under 60 seconds without tools, fits most riding mowers/garden tractors.
- Colors: 4 (Grå / Svart / Grön / Ljusgrå).
- **Price: 649 kr. Original: 811 kr.**
- Free shipping, Klarna, 30-day returns.
- Landing page: https://baverbutiken.se/products/satesoverdrag-for-akgrasklippare-slittaligt-600d-oxford

## Hard rules
1. Product on screen before second 4.
2. **Burned-in Swedish captions, word-for-word from each brief's table.** The account's most proven variable: the winner (with captions) sits at 80 purchases / ROAS 2.59; the identical caption-free cut is stuck at 2 purchases / ROAS 0.97 after three weeks.
3. Never re-translate Swedish. Check å/ä/ö at export.
4. **Raw, documentary, unpolished** — this account's proven style. Do not grade toward a commercial look.
5. Must work fully muted.
6. Export **9:16 (1080×1920) AND 4:5 (1080×1350)**.
7. File name = folder's ad name exactly. Never reuse an AD ID.
8. No fabricated testimonials or "Verifierad kund" claims.

## Critical production note
**`PD_18_H1` must reuse the `PD_13_H1` master edit unchanged** — the only difference between the two ads is caption line 4 (the price). If you re-cut or re-shoot it, the comparison is destroyed and we learn nothing. `PD_19_H1` needs one new 4s opener (jacket/blanket) on the same winner body.

## KPI context
Break-even CPA 474 kr · target CPA 300 kr · winner benchmark 274 kr · PD_13 benchmark 329 kr. Judge only after ≥300 kr spend AND ≥3 purchases.
