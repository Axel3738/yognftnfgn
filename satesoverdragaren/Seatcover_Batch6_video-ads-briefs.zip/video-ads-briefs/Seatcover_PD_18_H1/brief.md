# Seatcover_PD_18_H1 — Proven towel hook + price moved INTO the video

**Variables:** angle=behaviour-callout → price qualification · hook=question/observation (proven) · format=raw video w. captions · proof=demo · offer=**price shown in-video at 7–9s** · speaker=none · text=full captions

**Type:** Iteration on `Seatcover_PD_13_H1` — the account's first briefed ad to reach significance (6 purchases, CPA 329 kr, profitable)
**Format:** ~20s video · 9:16 + 4:5 · burned-in Swedish captions
**Production level:** Simple (same edit as PD_13, one caption line changed)
**Primary KPI:** CPA (target < 300 kr, break-even 474 kr) · **decisive diagnostic: LPV→purchase rate** (must beat PD_13's 1.81 %)

## Hypothesis — built directly on what PD_13 measured
`PD_13_H1` proved the towel hook works as *attention*: CTR **3.87 %** (highest of any PD ad in the account, vs the winner's 2.69 %) and hold **13.6 %** (better than the winner's 11.7 %). But it converts worse once they land: **LPV→purchase 1.81 % vs the winner's 2.67 %**. It is profitable (CPA 329 kr, well under break-even 474 kr) — but the recognition hook pulls in a broader, less purchase-ready audience.

The fix is not a better hook — it's **qualifying earlier**. This version puts the price and the cost comparison at second 7–9, inside the video, instead of leaving it to the ad copy. People unwilling to pay 649 kr drop before clicking rather than after; the ones who stay are pre-qualified. Isolated variable: **price introduced in-video** (hook, footage, USP order and CTA all held constant vs PD_13).

## What is kept / what changes
- KEPT: the exact towel hook (proven), PD_13's footage and edit, caption styling, USP order, CTA.
- CHANGED: caption line 4 now carries the price and the cost anchor; the rest shifts ~2s later. Nothing else.

## Script / caption table
| # | Time | Swedish (use this) | English meaning |
|---|---|---|---|
| 1 | 0–2s | Lägger du en handduk på sätet innan du kör? | Do you put a towel on the seat before you drive? |
| 2 | 2–4s | Den håller typ en dag. | It lasts about a day. |
| 3 | 4–7s | Så vi gjorde ett riktigt sätesöverdrag istället. | So we made a real seat cover instead. |
| 4 | 7–9s | **Ett nytt säte kostar flera tusenlappar – det här kostar 649 kr.** | A new seat costs several thousand kronor – this costs 649 kr. |
| 5 | 9–12s | 600D Oxford-tyg, vattenavvisande. | 600D Oxford fabric, water-repellent. |
| 6 | 12–15s | Vadderad insida och justerbara remmar. | Padded interior and adjustable straps. |
| 7 | 15–18s | På plats på under 60 sekunder, inga verktyg. | In place in under 60 seconds, no tools. |
| 8 | 18–20s | Handla nu – fri frakt och öppet köp. | Shop now – free shipping and open purchase. |

## Shot list
Identical to `PD_13_H1`. 0–4s: towel on a bare seat, hand lifts it away revealing the wet seat. 4s onward: winner master footage (cover glides on, straps, padding, wide, end-card). **Do not re-shoot** — reuse the PD_13 master so the only difference between the two ads is caption line 4.

## Editing direction
- Caption 4 is the whole experiment: give it the most visual weight of any caption in the video (larger, or held a beat longer). "649 kr" may be emphasised in size; do not change the wording.
- Everything else identical to PD_13: white text, black outline, bottom third, word-for-word.
- Must work fully muted.

## CTA
Button: **Handla nu** (SHOP_NOW).

## Ad copy
| Field | Swedish (use this) | English meaning |
|---|---|---|
| Primary text | Lägger du en handduk på sätet innan du kör din åkgräsklippare? Den håller ungefär en dag. Ett sätesöverdrag i slittåligt 600D Oxford-tyg håller väder efter väder – och kostar 649 kr, jämfört med flera tusenlappar för ett nytt säte. Vadderad insida, justerbara remmar och på plats på under 60 sekunder utan verktyg. Handla nu – fri frakt och nöjd-kund-garanti. | Do you put a towel on the seat before driving? It lasts about a day. A 600D Oxford cover holds up rain after rain – and costs 649 kr vs several thousand for a new seat. |
| Headline | Sätesöverdrag för åkgräsklippare – 649 kr | Ride-on mower seat cover – 649 kr |

## What we learn regardless of outcome
- **CVR rises toward 2.67 % and CPA drops below 329 kr** → early price qualification fixes the recognition hook's weakness. Apply the same 7–9s price line to every high-CTR/low-CVR ad in the account.
- **CVR rises but CTR collapses** → the price scares off exactly the volume the hook won us; the two effects cancel and the lane has a hard ceiling.
- **Nothing changes** → the gap between PD_13 and the winner is audience quality that in-video price can't fix; the next test must change the offer or the landing page, not the creative.
