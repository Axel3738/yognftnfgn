# Seatcover_PD_19_H1 — Second behaviour callout (jacket/blanket)

**Variables:** angle=behaviour-callout · hook=question/observation (proven type, new content) · format=raw video w. captions · proof=demo · offer=price in copy only · speaker=none · text=full captions

**Type:** Replication of a proven hook TYPE with new content — `Seatcover_PD_13_H1` (6 purchases, CTR 3.87 %, best PD click-through in the account)
**Format:** ~20s video · 9:16 + 4:5 · burned-in Swedish captions
**Production level:** Simple (winner master footage + one new 4s opener)
**Primary KPI:** CPA (target < 300 kr, break-even 474 kr) · diagnostic: CTR (does the hook *type* replicate, or was the towel specifically lucky?)

## Hypothesis
`PD_13_H1` proved that **naming a workaround the owner already uses** stops more people than describing the problem: CTR 3.87 % vs the winner's 2.69 %, hold 13.6 % vs 11.7 %. But that is one data point on one behaviour (the towel). We do not yet know whether the *category* of hook replicates or whether the towel just happens to be a very common habit.

This ad runs the same hook type on a different behaviour — the jacket or blanket thrown over the seat. If CTR lands near 3.87 %, behaviour-callout is a repeatable hook formula we can mine indefinitely (rag-wiping, sitting on it anyway, plastic bag). If it lands near 2.7 %, the towel was the insight, not the format. Isolated variable: **which behaviour is called out** (structure, footage, USPs and CTA all held constant vs PD_13).

**Tone note:** self-deprecating and recognising, never accusing. "Vi har alla gjort det" — we've all done it. The viewer should feel seen, not told off.

## What is kept / what changes
- KEPT: PD_13's structure beat-for-beat, winner master footage from ~4s, caption styling, USP order, CTA, price left out of the video.
- CHANGED: the 0–4s hook — jacket/blanket instead of towel, with a new pickup shot.

## Script / caption table
| # | Time | Swedish (use this) | English meaning |
|---|---|---|---|
| 1 | 0–2s | Lägger du en jacka eller filt på sätet innan du sätter dig? | Do you put a jacket or blanket on the seat before you sit down? |
| 2 | 2–4s | Vi har alla gjort det. Det hjälper typ noll. | We've all done it. It helps basically zero. |
| 3 | 4–6s | Trä sätesöverdraget över dynan istället. | Slip the seat cover over the cushion instead. |
| 4 | 6–9s | 600D Oxford-tyg som stänger ute vatten. | 600D Oxford fabric that keeps water out. |
| 5 | 9–12s | Vadderad insida som skonar ryggen. | Padded interior that's gentle on your back. |
| 6 | 12–15s | Klart på under 60 sekunder, inga verktyg behövs. | Done in under 60 seconds, no tools needed. |
| 7 | 15–18s | Fri frakt, Klarna och öppet köp i 30 dagar. | Free shipping, Klarna and 30 days open purchase. |
| 8 | 18–20s | Handla nu. | Shop now. |

## Shot list
| Time | Shot | Source |
|---|---|---|
| 0–2s | A jacket or old blanket bunched on a bare mower seat — clearly an improvised fix, not styled | New 3s pickup (phone, daylight). Any ordinary jacket/blanket; it must look genuinely used |
| 2–4s | Hand pulls it off → damp seat underneath | Same pickup |
| 4–9s | Winner master: cover glides over the seat, straps clicked | Existing winner master |
| 9–18s | Winner master: padding press, wide on mower | Existing winner master |
| 18–20s | Winner master closing + end-card | Existing winner master frame |

## Creator direction
No talent. Hands only. Same unpolished register as PD_13 — it should look like the viewer's own garage, not a set.

## Editing direction
- Hard cut at 4.0s from the removed jacket → cover sliding on.
- Captions white/black outline, bottom third, word-for-word. Never re-translate.
- Winner's music from 4s. Price never rendered in-video (that variable is tested separately in `PD_18_H1`).
- Must work fully muted.

## CTA
Button: **Handla nu** (SHOP_NOW).

## Ad copy
| Field | Swedish (use this) | English meaning |
|---|---|---|
| Primary text | Lägger du en jacka eller filt på sätet innan du sätter dig på åkgräsklipparen? Det hjälper knappt alls. Vårt sätesöverdrag i vattenavvisande 600D Oxford-tyg med vadderad insida sitter kvar och håller sätet torrt, oavsett väder. Trä det över dynan på under 60 sekunder, helt utan verktyg. Handla nu – fri frakt, Klarna och 30 dagars öppet köp. | Do you put a jacket or blanket on the seat before sitting down? It barely helps. Our water-repellent 600D Oxford cover with padded interior stays put and keeps the seat dry. On in under 60 seconds, no tools. |
| Headline | Sätesöverdrag som faktiskt håller torrt | Seat cover that actually keeps you dry |

## What we learn regardless of outcome
If CTR lands near PD_13's 3.87 % → **behaviour-callout is a repeatable hook formula**, not a one-off. That gives us a renewable hook supply (rag, plastic bag, sitting on it anyway) and every future video opens this way. If CTR drops to ~2.7 % → the towel specifically was the insight; hooks must be researched per-behaviour rather than generated from a template. Either answer is worth more than the ad itself.

---
**Global rules:** Product on screen before second 4. Burned-in Swedish captions word-for-word. Price 649 kr / ord. 811 kr only — never rendered in-video here. Export 9:16 (1080×1920) + 4:5 (1080×1350). Check å/ä/ö rendering. No fabricated testimonials or "Verifierad kund" claims. Landing page: https://baverbutiken.se/products/satesoverdrag-for-akgrasklippare-slittaligt-600d-oxford
