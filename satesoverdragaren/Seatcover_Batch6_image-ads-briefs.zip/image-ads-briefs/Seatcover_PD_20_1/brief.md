# Seatcover_PD_20_1 — Towel hook as a static (format transfer of a proven hook)

**Variables:** angle=behaviour-callout · hook=question (proven, from `PD_13_H1`) · format=static, 50/50 split · proof=implicit comparison · offer=price on bottom bar · speaker=none · text=headline + 2 panel labels + 2 support lines

**Type:** Format transfer — the account's best-clicking hook, moved from video to still image
**Format:** Static, 50/50 split · 1:1 (1080×1080) + 4:5 (1080×1350)
**Production level:** Simple (one pickup photo + one existing product frame)
**Primary KPI:** CPA (target < 300 kr, break-even 474 kr) · diagnostic: CTR vs the account's static average (~1.4 % in the SO lane)

## Hypothesis
The towel callout is the account's strongest attention device in video (`PD_13_H1`: CTR 3.87 %, highest of any PD ad). Statics in this account have the opposite profile — the price static converts at 6.3 % but only clicks at 1.42 %.

If the recognition hook carries into a still image, it should lift static CTR without the CVR penalty video suffered, because a static gives no time for a broad, curious audience to build up — people either recognise the towel habit and click, or scroll past. Isolated variable: **format** (video → static) on an otherwise proven hook.

## Exact on-image text
| Position | Swedish (use this) | English meaning | Styling |
|---|---|---|---|
| Headline | Lägger du fortfarande en handduk på sätet? | Do you still put a towel on the seat? | Bold, top, full width, max 2 lines |
| Left panel label | Håller typ en dag | Lasts about a day | Small caps chip on the towel side |
| Right panel label | Håller i alla väder | Holds up in all weather | Small caps chip on the cover side |
| Under left panel | Blöt igen efter första regnskuren. | Wet again after the first rain shower. | Body text |
| Under right panel | 600D Oxford-tyg, vattenavvisande och vadderat. | 600D Oxford fabric, water-repellent and padded. | Body text |
| Bottom bar | 649 kr – fri frakt & nöjd-kund-garanti | 649 kr – free shipping & satisfaction guarantee | Single line, full width |

**QA before export:** the word "överstruket" must appear NOWHERE (shipped bug in `SO_1_1_H1`). å/ä/ö check at 200 % zoom. Only the digit 649 appears.

## Design brief
- 50/50 vertical split. **LEFT:** a damp, rumpled towel lying on a bare mower seat — the exact image from the `PD_13_H1` pickup, or a new phone photo in the same unstyled register. It must look like a real improvised fix. **RIGHT:** the fitted cover on the same/similar seat (winner master frame).
- The two panels must be shot or cropped at a comparable angle so the eye reads them as before/after of the same problem.
- Left panel slightly desaturated, right panel neutral — subtle, not a heavy-handed grade.
- Real photography only, no AI-generated product, no people.
- Headline sits above both panels, not inside either one.

## Ad copy
| Field | Swedish (use this) | English meaning |
|---|---|---|
| Primary text | Handduken på sätet håller typ en dag – sen är du tillbaka på ruta ett. Vårt sätesöverdrag i 600D Oxford-tyg är byggt för att faktiskt hålla vattnet borta. ✅ Vattenavvisande 600D Oxford-tyg ✅ Vadderad insida ✅ På plats på under 60 sekunder, inga verktyg. Handla nu för 649 kr – fri frakt och nöjd-kund-garanti. | The towel lasts about a day – then you're back to square one. Our 600D Oxford cover is built to actually keep the water out. Water-repellent, padded, on in under 60 seconds. 649 kr, free shipping and satisfaction guarantee. |
| Headline | Sätesöverdrag som håller vad handduken inte gör | Seat cover that holds what the towel can't |

## CTA
Button: **Handla nu** (SHOP_NOW).

## What we learn regardless of outcome
If static CTR clears ~2 % (well above the SO lane's 1.42 %) **and** CVR holds → the hook travels across formats and we can build a whole static family on behaviour callouts, giving the account a high-click static lane it currently lacks. If CTR stays at static-average → the towel hook needs motion (the reveal of lifting it) to work, and recognition hooks stay a video-only tool.
