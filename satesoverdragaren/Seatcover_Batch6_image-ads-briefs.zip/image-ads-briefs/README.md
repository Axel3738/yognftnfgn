# Image Ad Briefs – Seatcover Batch #6 (2026-08-12)

Two statics. Both attack the same measured weakness. Read this before starting.

## Why this batch exists
The account has two proven pieces that do not overlap:

| Ad | Stops people | Converts them |
|---|---|---|
| `SO_1_1_H1` (price anchor static) | ❌ CTR 1.42 % | ✅ **6.33 %** LPV→purchase (best in account) |
| `PD_13_H1` (towel hook video) | ✅ **CTR 3.87 %** (best in account) | ❌ 1.81 % LPV→purchase |
| `PD_1_3_H1` (winner video) | CTR 2.69 % | 2.67 % |

The static lane converts brilliantly and clicks poorly. These two briefs test whether the account's best-clicking device — the towel/behaviour callout — can lift static CTR:

- **`PD_20_1`** = format transfer. The towel hook as a 50/50 before/after still image.
- **`SO_7_1`** = message swap. The proven `SO_1_1_H1` offer graphic, with a recognition question replacing the price statement in the headline position.

Batch #5's `SO_5_1` (typography) and `SO_6_1` (photography) are already running at the same problem from other directions. Together the four isolate whether low static CTR is a **type**, **picture**, **format** or **wording** problem.

## Product facts (never improvise)
- 600D Oxford, water-repellent, padded inside, adjustable straps, on in under 60 seconds without tools, fits most riding mowers/garden tractors.
- Colors: 4 (Grå / Svart / Grön / Ljusgrå).
- **Price: 649 kr. Original: 811 kr.**
- Free shipping, Klarna, 30-day returns.
- Landing page: https://baverbutiken.se/products/satesoverdrag-for-akgrasklippare-slittaligt-600d-oxford

## Hard rules
1. **Real photography only.** No AI-generated product, no AI-generated people. The account's raw, unstyled register is proven — do not polish toward stock.
2. **The word "överstruket" must appear NOWHERE.** This exact AI text bug shipped live in `SO_1_1_H1` and had to be replaced. Strikethrough = a real drawn line over the number.
3. Swedish on-image text word-for-word from each brief's table. Never re-translate. Check å/ä/ö at 200 % zoom before export.
4. Only prices and the numbers listed in each brief appear as digits — no invented percentages, ratings or review counts.
5. No fabricated testimonials, no "Verifierad kund" badges. (Two ads with invented testimonials already shipped in this account and are pending removal.)
6. Export **1:1 (1080×1080) AND 4:5 (1080×1350)**.
7. File name = folder's ad name exactly. Never reuse an AD ID.

## KPI context
Break-even CPA 474 kr · target CPA 300 kr · winner benchmark 274 kr · static benchmark `SO_1_1_H1` CPA 308 kr / CTR 1.42 %. Judge only after ≥300 kr spend AND ≥3 purchases.
