# Seatcover_SO_7_1 — Price anchor with a recognition hook as the headline

**Variables:** angle=behaviour-recognition → price anchor · hook=question (recognition) · format=offer graphic · proof=none · offer=price shown (649/811) · speaker=none · text=headline + subhead + price block

**Type:** Cross of the account's two proven elements — `SO_1_1_H1`'s converting message + `PD_13_H1`'s stopping power
**Format:** Static · 1:1 (1080×1080) + 4:5 (1080×1350)
**Production level:** Simple
**Primary KPI:** CPA (target < 300 kr, break-even 474 kr) · **decisive diagnostic: CTR** (must beat `SO_1_1_H1`'s 1.42 % while holding its 6.3 % LPV→purchase)

## Hypothesis — this brief exists because the two proven ads have opposite weaknesses
| | Stops people | Converts them |
|---|---|---|
| `SO_1_1_H1` (price anchor) | ❌ CTR 1.42 % | ✅ **6.33 %** LPV→purchase |
| `PD_13_H1` (towel hook) | ✅ **CTR 3.87 %** | ❌ 1.81 % LPV→purchase |
| `PD_1_3_H1` (winner) | CTR 2.69 % | 2.67 % |

Neither is a ceiling on the other: the price message converts best in the account, the recognition hook stops best. This ad puts the **recognition hook in the headline position** and lets the price anchor do the closing underneath. Isolated variable: **headline register** (recognition question vs price statement) inside the proven SO offer-graphic format.

**Note:** batch #5's `SO_5_1` and `SO_6_1` attack the same CTR problem via typography and photography. This one attacks it via **message**. All three should run together — between them they isolate whether the SO lane's low CTR is a type problem, a picture problem or a wording problem.

## Exact on-image text
| Position | Swedish (use this) | English meaning | Styling |
|---|---|---|---|
| Headline | Trött på det blöta sätet? | Tired of the wet seat? | Largest element, top. This is the stopping device |
| Subhead | Ett nytt säte kostar tusenlappar. Det här kostar betydligt mindre. | A new seat costs thousands. This costs considerably less. | Two lines under the headline |
| Price block | 811 kr → 649 kr | 811 kr → 649 kr | 811 with a **REAL drawn strikethrough line**; 649 largest, account yellow |
| Bottom bar | Fri frakt, Klarna & 30 dagars öppet köp | Free shipping, Klarna & 30 days open purchase | Single line, full width |

**QA before export — non-negotiable:** the word "överstruket" must appear NOWHERE (this exact AI bug shipped in `SO_1_1_H1` and had to be replaced). Strikethrough = drawn line. å/ä/ö at 200 % zoom. Only 811, 649 and 30 appear as digits.

## Design brief
- Layout follows the proven `SO_1_1_H1` composition — price block prominent, product lower-right, bottom bar full width. **Keep what converts; change only the headline register.**
- Product: real photography of the fitted cover (winner master frame or existing product static). No AI-generated product, no people.
- The headline must dominate the price block visually — the recognition question is what does the stopping; the price is what does the closing. If the price is the first thing the eye hits, the test has been built backwards.

## Ad copy
| Field | Swedish (use this) | English meaning |
|---|---|---|
| Primary text | Ett nytt säte till åkgräsklipparen kostar snabbt flera tusenlappar. Vårt sätesöverdrag i slittåligt 600D Oxford-tyg skyddar sätet du redan har – för 649 kr istället för ordinarie 811 kr. ✅ Vattenavvisande 600D Oxford-tyg ✅ Vadderad insida med justerbara remmar ✅ På plats på under 60 sekunder. Handla nu – fri frakt och nöjd-kund-garanti. | A new seat quickly costs several thousand kronor. Our durable 600D Oxford cover protects the seat you already have – 649 kr instead of the regular 811 kr. |
| Headline | 649 kr istället för ett nytt säte | 649 kr instead of a new seat |

## CTA
Button: **Handla nu** (SHOP_NOW).

## What we learn regardless of outcome
- **CTR up + CVR holds** → the two proven elements compose, and the account gets a static that both stops and closes. That would be the single most valuable creative finding so far.
- **CTR up + CVR falls toward PD_13's 1.81 %** → the recognition hook *carries its audience with it*: whoever it attracts converts poorly regardless of what follows. That is a far more important lesson than this one ad, and it would mean the towel lane should stay in video where cheap reach makes low CVR affordable.
- **CTR flat** → the SO lane's low click-through is not a wording problem; the answer must come from `SO_5_1` (typography) or `SO_6_1` (photography) instead.
