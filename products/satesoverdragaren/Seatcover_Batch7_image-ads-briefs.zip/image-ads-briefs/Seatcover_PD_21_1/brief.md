# Seatcover_PD_21_1 — Second behaviour callout as a static (jacket)

**Variables:** angle=behaviour-callout · hook=question (proven type, new content) · format=static, 50/50 split · proof=implicit comparison · offer=price on bottom bar · speaker=none · text=headline + 2 panel labels + 2 support lines

**Type:** Replication of the account's best static with a different behaviour
**Format:** Static, 50/50 split · 1:1 (1080×1080) + 4:5 (1080×1350)
**Production level:** Simple (one pickup photo + one existing product frame)
**Primary KPI:** CPA (target < 300 kr, break-even 474 kr) · diagnostic: CTR vs `PD_20_1`'s 2,66 %

## Hypothesis

`PD_20_1` is the account's best static: CTR 2,66 %, LPV→purchase 9,62 %, CPA 191 kr, 1,49 kr profit per krona. It calls out one behaviour: the towel.

That is one data point on one habit. If the **category** replicates, behaviour-callout becomes a renewable static format we can mine indefinitely (jacket, blanket, plastic bag, sitting on it anyway). If it does not, the towel was the insight and each new static needs its own research.

**Isolated variable: which behaviour is called out.** Layout, panel structure, styling and bottom bar are held identical to `PD_20_1`.

## Exact on-image text
| Position | Swedish (use this) | English meaning | Styling |
|---|---|---|---|
| Headline | Lägger du fortfarande en gammal jacka över sätet? | Still using an old jacket on the seat? | Bold, top, full width, max 2 lines |
| Left panel label | Gammal jacka | Old jacket | Small caps chip on the jacket side |
| Right panel label | Riktigt sätesöverdrag | Proper seat cover | Small caps chip on the cover side |
| Under left panel | Glider av och skyddar sällan hela sätet. | Blows off and rarely protects the whole seat. | Body text |
| Under right panel | Sitter kvar med justerbara remmar i slittåligt 600D Oxfordtyg. | Stays put with adjustable straps in durable 600D Oxford fabric. | Body text |
| Bottom bar | Nu 649 kr med fri frakt. | Now 649 kr with free shipping. | Single line, full width |

**QA before export:** the word "överstruket" must appear NOWHERE. No percentage. No stock count. Only the digit 649 appears. å/ä/ö at 200 % zoom.

## Design brief
- **Copy `PD_20_1`'s layout exactly.** 50/50 vertical split, headline above both panels, chips in the same positions, same type scale, same bottom bar. This is a content test, not a design test — any layout change contaminates it.
- **LEFT:** an ordinary jacket bunched on a bare mower seat, clearly improvised, half sliding off. New phone photo in the same unstyled register as the towel shot.
- **RIGHT:** the fitted cover on the same or a similar seat, winner master frame.
- Comparable angle on both panels so the eye reads before and after. Left slightly desaturated, right neutral, subtle.
- Real photography only, no AI-generated product, no people.

## Ad copy
| Field | Swedish (use this) | English meaning |
|---|---|---|
| Primary text | Lägger du en gammal jacka eller filt över sätet för att skydda det? Den glider av, sitter löst och skyddar sällan hela dynan. Vårt sätesöverdrag är sytt i slittåligt 600D Oxfordtyg, vattenavvisande och vadderat på insidan, med justerbara remmar som håller det på plats. Det är på plats på under 60 sekunder, helt utan verktyg. Just nu 649 kr istället för ordinarie 811 kr, med fri frakt, Klarna och 30 dagars öppet köp. Beställ ett riktigt sätesöverdrag nu. | Do you put an old jacket or blanket over the seat? It slides off and rarely covers the whole cushion. Durable 600D Oxford, water-repellent, padded, adjustable straps. On in under 60 seconds. Now 649 kr instead of 811 kr. |
| Headline | Bättre skydd än en gammal jacka | Better protection than an old jacket |

## CTA
Button: **Handla nu** (SHOP_NOW).

## What we learn regardless of outcome
CTR near 2,66 % → **behaviour-callout is a repeatable static formula** and we can build a family of them. CTR near the SO lane's 1,30 % → the towel specifically was the insight, and behaviours must be researched one at a time rather than generated from a template.

---
**Global rules:** Real photography only, no AI-generated product or people. Swedish on-image text word-for-word. Price 649 kr / ordinarie 811 kr only, never a percentage. Strikethrough is a drawn line, never the word "överstruket". No stock counts, no end date, no countdown. Export 1:1 (1080×1080) + 4:5 (1080×1350). Check å/ä/ö at 200 % zoom. No fabricated testimonials. Landing page: https://baverbutiken.se/products/satesoverdrag-for-akgrasklippare-slittaligt-600d-oxford
