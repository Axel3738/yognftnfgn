# Seatcover_SO_8_1 — Offer-first as a static

**Variables:** angle=clearance reason-why · hook=reason-why statement · format=offer graphic · proof=none · offer=price shown (649/811) · speaker=none · text=headline + subhead + price block

**Type:** Format transfer of the account's most profitable message
**Format:** Static · 1:1 (1080×1080) + 4:5 (1080×1350)
**Production level:** Simple
**Primary KPI:** CPA (target < 300 kr, break-even 474 kr) · diagnostic: CTR vs `SO_1_1_H1`'s 1,30 %

## Hypothesis

Two things are now proven separately:
1. **Offer-first wins in video.** `bryn swipe 1` opens on "we over-ordered" and returns **2,10 kr profit per krona spent**, the best in the account.
2. **A hook that works in video can transfer to static.** `PD_20_1` proved exactly that last batch, moving the towel callout from video to still image and landing CTR 2,66 % with LPV→purchase 9,62 %.

Nobody has combined them. This puts the reason-why in the headline position of the proven SO offer-graphic layout. **Isolated variable: headline register** (reason-why statement vs price statement) inside a layout we already know converts.

## Exact on-image text
| Position | Swedish (use this) | English meaning | Styling |
|---|---|---|---|
| Headline | Vi beställde in för många sätesöverdrag. | We ordered in too many seat covers. | Largest element, top. This is the stopping device |
| Subhead | Därför säljer vi ut lagret till nedsatt pris. | That's why we're selling off the stock at a reduced price. | One line under the headline |
| Price block | 811 kr → 649 kr | 811 kr → 649 kr | 811 with a **REAL drawn strikethrough line**; 649 largest, account yellow |
| Bottom bar | Fri frakt, Klarna och 30 dagars öppet köp. | Free shipping, Klarna, and 30 days open purchase. | Single line, full width |

**QA before export:** the word "överstruket" must appear NOWHERE. No percentage anywhere on the image. No stock count, no end date, no countdown. Only 811, 649 and 30 appear as digits. å/ä/ö at 200 % zoom.

## Design brief
- Follow the proven `SO_1_1_H1` composition: price block prominent, product lower right, bottom bar full width. **Change only the headline register.**
- The headline must dominate the price block. The reason is what stops the scroll here; the price is what closes.
- Real photography of the fitted cover. No AI-generated product, no people.
- **FOTOKRAV, skärpt efter visuell granskning 2026-08-19.** The SO lane's product shots have so far been **studio composites on a black background** (`SO_5_1`, `SO_7_1`). The one SO ad that used a real photograph of a mower standing in a garden (`SO_6_1`) has the lane's highest CTR at 2,39 %, against 1,43 % and 2,21 % for the two composites. **Do not use a floating product render on a flat background.** Use a real photograph, outdoors, of a real machine. This is now the single clearest lever we have on the SO lane.
- Plain and factual in tone. This is an honest explanation, not a sale banner. No starbursts, no "REA" flashes, no red price tags.

## Ad copy
| Field | Swedish (use this) | English meaning |
|---|---|---|
| Primary text | Vi beställde in fler sätesöverdrag för åkgräsklippare än vi behöver, och nu säljer vi ut lagret. Överdraget är sytt i slittåligt 600D Oxfordtyg, vattenavvisande och vadderat på insidan för extra skydd åt sätesdynan. Justerbara remmar håller det på plats oavsett modell, och du trär det över sätet på under 60 sekunder utan verktyg. Just nu 649 kr istället för ordinarie 811 kr, med fri frakt, Klarna och 30 dagars öppet köp. Beställ ditt sätesöverdrag nu, så långt lagret räcker. | We ordered more than we need and are selling the stock down. Durable 600D Oxford, water-repellent, padded, adjustable straps, on in under 60 seconds. Now 649 kr instead of 811 kr. |
| Headline | Lagerutförsäljning: 649 kr | Clearance: 649 kr |

## CTA
Button: **Handla nu** (SHOP_NOW).

## What we learn regardless of outcome
If CTR clears 2 % and CVR holds → offer-first is a **message-level** win, not a video-format win, and it belongs at the top of every asset we make. If CTR lifts but CVR falls → the reason-why pulls bargain hunters who do not convert at 649 kr. If nothing moves → offer-first needs the spoken, human delivery of the video to work, and stays a video device.

---
**Global rules:** Real photography only, no AI-generated product or people. Swedish on-image text word-for-word. Price 649 kr / ordinarie 811 kr only, never a percentage. Strikethrough is a drawn line, never the word "överstruket". No stock counts, no end date, no countdown. Export 1:1 (1080×1080) + 4:5 (1080×1350). Check å/ä/ö at 200 % zoom. No fabricated testimonials. Landing page: https://baverbutiken.se/products/satesoverdrag-for-akgrasklippare-slittaligt-600d-oxford
