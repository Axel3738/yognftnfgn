# Seatcover_SO_9_1 — Best static plus the price close

**Variables:** angle=behaviour-callout → price anchor · hook=question (proven) · format=static, 50/50 split + price line · proof=implicit comparison · offer=price shown · speaker=none · text=headline + 2 labels + price line + bottom bar

**Type:** Additive test on the account's best static
**Format:** Static, 50/50 split · 1:1 (1080×1080) + 4:5 (1080×1350)
**Production level:** Simple (reuses `PD_20_1`'s photography)
**Primary KPI:** CPA (target < 300 kr, break-even 474 kr) · diagnostic: LPV→purchase vs `PD_20_1`'s 9,62 %

## Hypothesis

`PD_20_1` stops people and converts them (CTR 2,66 %, LPV→purchase 9,62 %) but carries only a bare price on the bottom bar. `SO_1_1_H1` and `SO_7_1` show the **cost comparison** is the account's best closing argument.

This adds the closing argument to the winning static without touching what makes it win. **Isolated variable: the price line.** Headline register, panel structure and photography are held constant against `PD_20_1`.

The headline is deliberately reworded rather than copied so the two ads are not near-duplicates in the auction, but it keeps the same recognition trigger.

## Exact on-image text
| Position | Swedish (use this) | English meaning | Styling |
|---|---|---|---|
| Headline | Ligger det fortfarande en handduk på förarsätet? | Still got a towel on the driver's seat? | Bold, top, full width, max 2 lines |
| Left panel label | Bara en handduk | Just a towel | Small caps chip on the towel side |
| Right panel label | Riktigt sätesöverdrag | Proper seat cover | Small caps chip on the cover side |
| Price line | Ett nytt säte kostar tusenlappar. Vårt överdrag kostar 649 kr. | A new seat costs thousands. Our cover costs 649 kr. | **The new element.** Sits between the panels and the bottom bar, clearly separated |
| Bottom bar | Fri frakt, Klarna och 30 dagars öppet köp. | Free shipping, Klarna, and 30 days open purchase. | Single line, full width |

**QA before export:** the word "överstruket" must appear NOWHERE. No percentage. No stock count, no end date. Only 649 and 30 appear as digits. å/ä/ö at 200 % zoom.

## Design brief
- Reuse `PD_20_1`'s photography and panel layout unchanged. Damp towel on a bare seat left, fitted cover right.
- The price line is an **addition**, not a replacement. The headline must still be the largest element; if the price line competes with it, the test is contaminated.
- Real photography only, no AI-generated product, no people.

## Ad copy
| Field | Swedish (use this) | English meaning |
|---|---|---|
| Primary text | Ligger det fortfarande en handduk på sätet på åkgräsklipparen? Ett nytt säte kostar flera tusenlappar, men ett bra överdrag kostar betydligt mindre. Vårt sätesöverdrag är sytt i slittåligt 600D Oxfordtyg, vattenavvisande och vadderat på insidan, med justerbara remmar för universell passform. Du trär det över den befintliga sätesdynan på under 60 sekunder, helt utan verktyg. Nu 649 kr istället för ordinarie 811 kr, med fri frakt, Klarna och 30 dagars öppet köp. Byt ut handduken mot ett riktigt överdrag nu. | Still a towel on the mower seat? A new seat costs thousands, a good cover costs far less. Durable 600D Oxford, water-repellent, padded, adjustable straps, universal fit. On in under 60 seconds. Now 649 kr instead of 811 kr. |
| Headline | Släng handduken. Nu 649 kr. | Ditch the towel. Now 649 kr. |

## CTA
Button: **Handla nu** (SHOP_NOW).

## What we learn regardless of outcome
CVR rises above 9,62 % → the price close composes with the behaviour hook and every future static gets both. CVR falls → the static was winning **because** it stayed a single idea, and adding arguments dilutes it. That second answer would be just as valuable, because it sets a rule for every static we build after this.

---
**Global rules:** Real photography only, no AI-generated product or people. Swedish on-image text word-for-word. Price 649 kr / ordinarie 811 kr only, never a percentage. Strikethrough is a drawn line, never the word "överstruket". No stock counts, no end date, no countdown. Export 1:1 (1080×1080) + 4:5 (1080×1350). Check å/ä/ö at 200 % zoom. No fabricated testimonials. Landing page: https://baverbutiken.se/products/satesoverdrag-for-akgrasklippare-slittaligt-600d-oxford
