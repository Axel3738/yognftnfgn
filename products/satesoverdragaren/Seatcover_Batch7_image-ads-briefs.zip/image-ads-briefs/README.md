# Image Ad Briefs – Seatcover Batch #7 (2026-08-14)

Three statics, all built on one result from last batch.

## Why this batch exists
`PD_20_1` moved the towel callout from video into a still image and became **the account's best static**: CTR 2,66 % against the SO lane's 1,30 to 1,43 %, LPV→purchase 9,62 %, CPA 191 kr, 1,49 kr profit per krona spent.

That single result raises three questions, one per brief:

| Brief | Question it answers |
|---|---|
| `PD_21_1` | Does the **behaviour callout** replicate on a different habit (jacket instead of towel), or was the towel the whole insight? |
| `SO_9_1` | Does adding the **price close** to the winning static lift conversion further, or does a second argument dilute it? |
| `SO_8_1` | Does **offer-first**, which is winning in video, transfer into a static the way the towel callout did? |

`PD_21_1` and `SO_9_1` must copy `PD_20_1`'s layout exactly. They are content tests, not design tests, and any layout change contaminates them.

## Product facts (never improvise)
- 600D Oxford, water-repellent, padded inside, adjustable straps, universal fit, on in under 60 seconds without tools.
- **Price now 649 kr. Ordinarie 811 kr.** Never state a percentage.
- Free shipping, Klarna, 30-day open purchase.
- A real clearance is running: we over-ordered and are selling stock down. "Så långt lagret räcker" is the only scarcity phrasing allowed.
- **Do not name colours.** Two of the four are currently unavailable, so no static in this batch mentions colour at all.

## Hard rules
1. **Real photography only.** No AI-generated product, no AI-generated people.
2. **The word "överstruket" must appear NOWHERE.** This exact bug shipped live once. Strikethrough is a drawn line over the number.
3. **No percentage anywhere on the image.** Kronor only: 649 and ordinarie 811.
4. No stock counts, no end date, no countdown, no "sista chansen".
5. No fabricated testimonials, no "verifierad kund" badges.
6. Swedish on-image text word-for-word. Check å/ä/ö at 200 % zoom.
7. Export 1:1 (1080×1080) AND 4:5 (1080×1350).
8. File name = folder name exactly. Never reuse an AD ID.

## KPI context
Break-even CPA 474 kr · target CPA 300 kr · best static benchmark `PD_20_1` CPA 191 kr / CTR 2,66 %. Judge only after ≥300 kr spend AND ≥3 purchases.
