# Seatcover_SP_9_H1 — Swipe body, price-contrast hook (hook test H3)

**Variables:** angle=price anchor → offer body · hook=price contrast · format=spokesperson VO over demo footage w. captions · proof=mechanism · offer=stated in hook and body · speaker=voice only · text=full captions

**Type:** Hook swap on the account's most profitable ad, `bryn swipe 1`
**Format:** ~76s video · 9:16 + 4:5 · burned-in Swedish captions
**Production level:** Trivial (existing body + one new 8s opener)
**Primary KPI:** CPA (target < 300 kr, break-even 474 kr) · diagnostic: CTR and LPV→purchase vs H1 and H2

## Hypothesis

Third arm of the same test. `SP_8_H1` opens on a behaviour, `SP_9_H1` opens on the money, and `bryn swipe 1` (H1) opens on the reason-why. All three run the identical body.

The price contrast is the account's best-converting **message** (`SO_1_1_H1`: LPV→purchase 6,80 %, and `SO_7_1` at CPA 88 kr on early data), but it has never been tested as a video opener on a proven body.

**Isolated variable: the opening 8 seconds.** Beats 2 to 11 are byte-identical to `bryn swipe 1`.

## Script — new opener only

| # | Time | Swedish (use this) | English meaning |
|---|---|---|---|
| 1 | 0–8s | Ett nytt gräsklipparsäte kostar flera tusenlappar. Ett skyddande överdrag kostar bara 649 kronor. | A new mower seat costs several thousand kronor. A protective cover costs only 649 kronor. |

**Everything from 8s onward is the existing `bryn swipe 1` master, untouched.**

## Shot list
0–8s: wide on the mower with the fitted cover, then a close on the price rendered on screen. Winner master footage. Hard cut at 8,0s into the existing body.

## Ad copy
| Field | Swedish (use this) | English meaning |
|---|---|---|
| Primary text | Vi beställde in fler sätesöverdrag för åkgräsklippare än vi behöver, och nu säljer vi ut lagret. Överdraget är sytt i slittåligt 600D Oxfordtyg, vattenavvisande och vadderat på insidan för extra skydd åt sätesdynan. Justerbara remmar håller det på plats oavsett modell, och du trär det över sätet på under 60 sekunder utan verktyg. Just nu 649 kr istället för ordinarie 811 kr, med fri frakt, Klarna och 30 dagars öppet köp. Beställ ditt sätesöverdrag nu, så långt lagret räcker. | We ordered more mower seat covers than we need and are selling the stock down. Durable 600D Oxford, water-repellent, padded, adjustable straps, on in under 60 seconds. Now 649 kr instead of 811 kr. |
| Headline | Lagerutförsäljning: 649 kr | Clearance: 649 kr |

## CTA
Button: **Handla nu** (SHOP_NOW).

## Three-way read
Run H1, H2 and H3 together and read them as one test. The account has never had a clean hook test on a proven body, and this is the cheapest information we can buy: three openers, one edit, one variable.

---
**Global rules:** Product on screen before second 4. Burned-in Swedish captions word-for-word, white text with black outline, bottom third. Price 649 kr / ordinarie 811 kr only, never a percentage. No stock counts, no end date, no countdown. Export 9:16 (1080×1920) + 4:5 (1080×1350). Check å/ä/ö at export. No fabricated testimonials or people. Landing page: https://baverbutiken.se/products/satesoverdrag-for-akgrasklippare-slittaligt-600d-oxford
