# Seatcover_SP_8_H1 — Swipe body, towel hook (hook test H2)

**Variables:** angle=behaviour-callout → offer body · hook=behaviour callout (proven) · format=spokesperson VO over demo footage w. captions · proof=mechanism · offer=stated in body · speaker=voice only · text=full captions

**Type:** Hook swap on the account's most profitable ad, `bryn swipe 1`
**Format:** ~76s video · 9:16 + 4:5 · burned-in Swedish captions
**Production level:** Trivial (existing body + one new 8s opener)
**Primary KPI:** CPA (target < 300 kr, break-even 474 kr) · diagnostic: CTR and LPV→purchase vs H1

## Hypothesis

`bryn swipe 1` is now the account's most efficient ad: **CPA 153 kr, 2,10 kr profit per krona spent, LPV→purchase 10,53 %** — all three the best of any assessable ad. But we cannot yet tell whether that comes from the reason-why **hook** or from the swipe **body** (the 11-beat argument). Every other proven asset in this account is a hook, so the question matters for everything we build next.

This runs the body unchanged with the account's other proven opener: the towel callout, which drives the highest video CTR we have (3,69 % vs the winner's 2,54 %).

**Isolated variable: the opening 8 seconds.** Beats 2 to 11 are byte-identical to `bryn swipe 1`.

## Script — new opener only

| # | Time | Swedish (use this) | English meaning |
|---|---|---|---|
| 1 | 0–8s | Lägger du en handduk på sätet innan du klipper gräset? Vi känner igen oss. Den håller typ en dag. | Do you put a towel on the seat before mowing? We know the feeling, it barely lasts a day. |

**Everything from 8s onward is the existing `bryn swipe 1` master, untouched.** Do not re-cut, re-grade or re-time the body. If the body is rebuilt the comparison is worthless and this ad teaches us nothing.

Note: the body's beat 2 introduces the clearance ("vi gick överstyr i vår senaste beställning"), so the offer still lands even though this opener does not mention it.

## Shot list
0–8s: damp towel bunched on a bare mower seat, a hand lifts it away revealing the wet cushion. Reuse the `PD_13_H1` pickup footage. Hard cut at 8,0s into the existing body.

## Ad copy
| Field | Swedish (use this) | English meaning |
|---|---|---|
| Primary text | Ligger det fortfarande en handduk på sätet på åkgräsklipparen? Ett nytt säte kostar flera tusenlappar, men ett bra överdrag kostar betydligt mindre. Vårt sätesöverdrag är sytt i slittåligt 600D Oxfordtyg, vattenavvisande och vadderat på insidan, med justerbara remmar för universell passform. Du trär det över den befintliga sätesdynan på under 60 sekunder, helt utan verktyg. Nu 649 kr istället för ordinarie 811 kr, med fri frakt, Klarna och 30 dagars öppet köp. Byt ut handduken mot ett riktigt överdrag nu. | Still a towel on the mower seat? A new seat costs thousands, a good cover costs far less. Durable 600D Oxford, water-repellent, padded, adjustable straps. On in under 60 seconds, no tools. Now 649 kr instead of 811 kr. |
| Headline | Släng handduken. Nu 649 kr. | Ditch the towel. Now 649 kr. |

## CTA
Button: **Handla nu** (SHOP_NOW).

## What we learn regardless of outcome
If CPA stays near 153 kr → **the body is what sells**, and we should mount every future hook on this argument structure. If CPA rises toward the account average → **the reason-why hook was doing the work**, and offer-first openings become the priority for all new video. Either answer redirects the next three batches.

---
**Global rules:** Product on screen before second 4. Burned-in Swedish captions word-for-word, white text with black outline, bottom third. Price 649 kr / ordinarie 811 kr only, never a percentage. No stock counts, no end date, no countdown. Export 9:16 (1080×1920) + 4:5 (1080×1350). Check å/ä/ö at export. No fabricated testimonials or people. Landing page: https://baverbutiken.se/products/satesoverdrag-for-akgrasklippare-slittaligt-600d-oxford
