# Video Ad Briefs – Seatcover Batch #7 (2026-08-14)

Three videos. Two of them are the same edit with different first 8 seconds. Read this before starting.

## Why this batch exists
`bryn swipe 1` is now the account's most efficient ad: **CPA 153 kr, 2,10 kr profit per krona spent, LPV→purchase 10,53 %.** All three figures are the best of any assessable ad, and it beats the long-running winner (CPA 302 kr) by a wide margin.

We do not know **why**. It could be the reason-why hook, or it could be the 11-beat body. `SP_8_H1` and `SP_9_H1` answer that by running the identical body behind two different openers.

## The single most important production rule in this batch
**Cut the body once. Mount three openers on it.**
`bryn swipe 1` (existing, H1), `SP_8_H1` (towel opener) and `SP_9_H1` (price opener) must share a byte-identical body from second 8 onward. Do not re-cut, re-grade, re-time or re-export the body per variant. If the bodies differ, the test measures nothing and three ads of production time are wasted.

## Product facts (never improvise)
- 600D Oxford, water-repellent, padded inside, adjustable straps, on in under 60 seconds without tools, fits most riding mowers and garden tractors.
- **Price now 649 kr. Ordinarie 811 kr.** Never state a percentage.
- Free shipping, Klarna, 30-day open purchase.
- A real clearance is running: we over-ordered and are selling stock down. "Så långt lagret räcker" is the only scarcity phrasing allowed. No end date, no countdown, no stock counts.

## Hard rules
1. Product on screen before second 4.
2. **Burned-in Swedish captions, word-for-word from each brief.** Proven: the caption-free cut of the winner is the account's only formally killed ad (CPA 531 kr against break-even 474 kr) while the captioned original sits at 302 kr.
3. Never re-translate the Swedish. Check å/ä/ö at export.
4. Raw and documentary, never polished. Voice-led means voice only, no face on camera.
5. Must work fully muted.
6. Export 9:16 (1080×1920) AND 4:5 (1080×1350).
7. File name = folder name exactly. Never reuse an AD ID.
8. No fabricated testimonials or people.

## KPI context
Break-even CPA 474 kr · target CPA 300 kr · winner benchmark 302 kr · swipe benchmark 153 kr. Judge only after ≥300 kr spend AND ≥3 purchases.
