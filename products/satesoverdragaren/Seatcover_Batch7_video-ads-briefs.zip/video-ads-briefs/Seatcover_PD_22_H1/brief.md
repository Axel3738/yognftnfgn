# Seatcover_PD_22_H1 — Controlled re-upload of the winner

**Variables:** angle=comfort/demo · hook=statement/demo (unchanged) · format=raw supplier video w. captions · proof=demo · offer=in copy only · speaker=none · text=full captions

**Type:** Controlled replication of an accidental finding
**Format:** identical to `PD_1_3_H1` · 9:16 + 4:5
**Production level:** Trivial (no new footage, no new copy in the video)
**Primary KPI:** CPA vs the original `PD_1_3_H1` running at the same time

## Hypothesis — this brief exists because of an accident

Someone duplicated the winner into a new ad (`PD_1_3_H1 – kopia`). It runs **the same creative** as the original but at **CPA 197 kr against the original's 302 kr**, on 5 purchases. If that is real, it means the winner's rising CPA is partly an **ad-level** effect (accumulated frequency and learning on that ad object) rather than creative fatigue — and the fix is nearly free: re-upload it.

That is worth a lot, so it deserves a controlled test rather than a conclusion. The copy was an accident with a small sample; this is the same move done deliberately, so the next `/cs` can judge it.

**Isolated variable: the ad object.** Same video file, same captions, same copy, same CTA, same landing page. Only the ad is new.

## What is kept / what changes
- KEPT: everything in the creative. Do not re-encode, do not re-cut, do not change the thumbnail.
- CHANGED: nothing except that it is uploaded as a new ad, launched alongside both the original and the existing copy.

## Read it like this
Three ad objects, one creative: the original (CPA 302 kr, 30 784 kr spend), the accidental copy (CPA 197 kr, 983 kr spend) and this one. If both fresh objects land near 200 kr while the original stays near 300 kr, the effect is real and re-uploading becomes standard practice on any scaled winner. If this one lands near 300 kr, the copy was small-sample luck and we stop talking about it.

**Do not pause the original.** The comparison needs all three running.

## Ad copy
| Field | Swedish (use this) | English meaning |
|---|---|---|
| Primary text | Ett torrt, bekvämt säte varje gång du sätter dig på åkgräsklipparen, det är vad vårt sätesöverdrag ger dig. Vadderat på insidan, vattenavvisande på utsidan och sytt i slittåligt 600D Oxfordtyg som tål alla säsonger. Justerbara remmar ger universell passform, och du sätter det på plats på under 60 sekunder utan verktyg. Vi beställde in för många och säljer nu ut till 649 kr istället för ordinarie 811 kr, med fri frakt, Klarna och 30 dagars öppet köp. Beställ ditt sätesöverdrag nu. | A dry, comfortable seat every time. Padded inside, water-repellent outside, durable 600D Oxford. Adjustable straps, universal fit, on in under 60 seconds without tools. We over-ordered and are selling down to 649 kr instead of 811 kr. |
| Headline | Torrt säte, nu 649 kr | Dry seat, now 649 kr |

## CTA
Button: **Handla nu** (SHOP_NOW).

---
**Global rules:** Product on screen before second 4. Burned-in Swedish captions word-for-word, white text with black outline, bottom third. Price 649 kr / ordinarie 811 kr only, never a percentage. No stock counts, no end date, no countdown. Export 9:16 (1080×1920) + 4:5 (1080×1350). Check å/ä/ö at export. No fabricated testimonials or people. Landing page: https://baverbutiken.se/products/satesoverdrag-for-akgrasklippare-slittaligt-600d-oxford
