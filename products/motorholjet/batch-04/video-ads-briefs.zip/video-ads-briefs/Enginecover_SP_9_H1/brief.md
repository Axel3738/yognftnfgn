# Enginecover_SP_9_H1 — UGC: the skeptic

**Type:** Creator UGC in the SP angle.
**Hypothesis:** A creator voicing the fit objection and disproving it on camera converts the doubters that the funnel data shows are stalling at the product page → LPV→purchase above 10 %.
**Kept:** The SP angle and the guarantee close.
**Changed (isolated variable):** New creator-filmed asset.

**Format:** Video, filmed 9:16, delivered 9:16 + 4:5 · **Production level:** **Advanced** (creator with boat access)
**Ad set:** Motorhölje SP · **CTA:** Handla nu · **Landing page:** https://baverbutiken.se/products/marin-motorholje-420d-universellt-skydd
**Source footage:** newly filmed by the creator.

## Why this ad exists
The social-proof angle converts at 10,9 % of landing-page visitors against 4,4 % for the volume ad, and its add-to-cart rate is 16 % against 9,2 %. It is the best-converting angle we own and it is under-supplied with assets.

## Creator script (Swedish word-for-word)
| Beat | Time | Swedish (use this) | English meaning |
|---|---|---|---|
| Hook | 0:00–0:04 | "De flesta universalhöljen sitter som en säck." | "Most universal covers fit like a sack." |
| Product | 0:04–0:09 | "Det här är 420D Oxfordtyg." | "This is 420D Oxford fabric." |
| Fitting | 0:09–0:16 | "Dragsko runt hela kanten. Jag drar åt, så här." | "Drawstring around the whole edge. I pull it tight, like this." |
| Proof | 0:16–0:22 | "Sitter still. Ingen säckform." | "Stays put. No sack shape." |
| Guarantee | 0:22–0:27 | "Passar den inte din motor? 30 dagars nöjd-kund-garanti." | "Does it not fit your engine? 30-day satisfaction guarantee." |
| CTA | 0:27–0:30 | "Handla nu." | "Shop now." |

**Creator direction:** 35-65, genuinely owns a boat. Dressed normally, no studio feel. Dry, honest, slightly amused. Product in frame within 4 seconds. Raw UGC grade, jump cuts on beat changes, captions always on.

The fit objection must be stated in the creator's own words and then disproven on camera in one unbroken take. If the cover does not sit well on the day, do not shoot around it — reshoot with the correct size.

## Ad copy
Primary text:
> De flesta universalhöljen sitter som en säck.
> Det här har dragsko runt hela kanten.
> 420D Oxfordtyg. Skyddar mot sol, regn och salt.
> 30 dagars nöjd-kund-garanti om det inte passar. 👇

Headline: `Sitter det verkligen? Se själv.`

**No fabricated proof:** no customer names, no star ratings, no review counts. We have no verified reviews.

**Size accuracy:** the six ranges are exactly as they appear in the store: 6 - 18 hk · 20 - 30 hk · 40 - 60 hk · 60 - 90 hk · 100 - 150 hk · 175 - 250 hk. Do not round, merge or invent ranges beyond what a brief explicitly states.

## Primary KPI
LPV→purchase (> 10 %), hold p50 (> 20 %) as diagnosis.

## What we learn regardless of outcome
Whether creator-led proof outperforms edited demo in the angle that already converts best.
